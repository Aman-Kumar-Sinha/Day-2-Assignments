

let foods=[
    {
        
            name:"Burger",
            price:100,
            quantity:400
        
    },
    {
            name:"Biryani",
            age:200,
            quantity:100
    },
    {
            name:"Pizza",
            age:300,
            quantity:120
    }
]




for(let num=0;num<foods.length;num++){
        console.log(foods[num])
        }


























